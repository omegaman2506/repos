<?php
session_start();

if (isset($_POST["auth_data"])) {
    $auth_data = json_decode($_POST['auth_data']);
    $login = $auth_data->login;
    $password = $auth_data->password;
    $count_bad_pass = $auth_data->count_bad_pass;
    require('config.php');

    if ($con_result['result'] == true) {
        $password = md5(trim($password));

        $sql_block = "SELECT * FROM accounts WHERE login = '$login' AND bad_pass = 1";
        $result = $connect->query($sql_block);
        if ($result->num_rows == 1) {
            echo json_encode([
                "result"=>false,
                "message"=>"Логин заблокирован"
            ]);
            return "";
        }

        $sql_nopass = "SELECT * FROM accounts WHERE login = '$login'";
        $result = $connect->query($sql_nopass);

        $data = [];
        if ($result->num_rows == 1) {
            //print_r('совпадение логина');
            foreach($result as $row){
                if ($password != $row['password']) {
                    $data['id'] = $row['id'];
                    //print_r('совпадение логина финиш');
                    setcookie("bad_pass",$count_bad_pass+1,time()+3600*12);
                    $check_id = $data['id'];
                    if ($count_bad_pass+1 == 6) {
                        $sql_ban = "UPDATE accounts SET bad_pass = 1 WHERE id = '$check_id'";
                        if ($connect->query($sql_ban) == true) {
                            setcookie ("bad_pass", 0, time() - 3600*12*5);
                            echo json_encode([
                                "result"=>false,
                                "message"=>"Логин заблокирован"
                            ]);
                            return "";
                        }
                    }
                    echo json_encode([
                        "result"=>false,
                        "message"=>"Введен неправильный пароль!"
                    ]);
                    return "";

                } elseif ($password == $row['password']) {
                    setcookie("bad_pass",0,time()+3600*12);
                            $data = [];
                            $data['login'] = $row['login'];
                            $data['password'] = $row['password'];
                            $data['name'] = $row['name'];
                            $data['birthdate'] = $row['birthdate'];
                            $data['id'] = $row['id'];

                            $data['result'] = true;
                            $data['message'] = 'Вы успешно авторизовались';

                            $_SESSION['login'] = $data['login'];
                            $_SESSION['password'] = $data['password'];
                            $_SESSION['id'] =$data['id'];

                            echo json_encode($data);
                            return "";
                }
            }
        } else {
            echo json_encode([
                "result"=>false,
                "message"=>"Не найден логин"
            ]);
        }
    }
    return '';
}

if (isset($_POST["reg_data"])) {
    $reg_data = json_decode($_POST['reg_data']);
    $login = $reg_data->login;
    $password = $reg_data->password;
    require 'config.php';

    if ($con_result['result'] == true) {
        $password = md5(trim($password));
        $sql_check = "SELECT * FROM accounts WHERE login = '$login' AND password = '$password'";
        $result = $connect->query($sql_check);

        $data = [];
        if ($result->num_rows > 0) {
            echo json_encode([
                "result"=>false,
                "message"=>"Такая учетка уже существует"
            ]);
            return "";
        } else {
            $sql_create ="INSERT INTO accounts (login, password) VALUES ('$login','$password')";

            $_SESSION['login'] = $login;
            $_SESSION['password'] = $password;
            $data = [];

            if ($connect->query($sql_create)) {

                $sql_check = "SELECT * FROM accounts WHERE login = '$login' AND password = '$password'";
                $result = $connect->query($sql_check);
                if ($result->num_rows == 1) {
                    foreach($result as $row){
                        $data['id'] = $row['id'];
                    }
                    $_SESSION['id'] = $data['id'];
                }

                echo json_encode([
                    "result"=>true,
                    "message"=>"Вы успешно зарегистрировались",
                    "info"=>[
                        "login" => $login,
                        "password" => $password
                    ]
                ]);
            }
            return "";
        }
    }
}

if (isset($_POST["change_data"])) {
    $change_data = json_decode($_POST['change_data']);
    $data_for_change = $change_data->data_from_input;
    $type_of_data = $change_data->type_data;

    require 'config.php';

    if ($con_result['result'] == true) {
        $login = $_SESSION["login"];
        $password = $_SESSION['password'];
        $id = $_SESSION['id'];

        if ($type_of_data != "password") {
            $sql_find = "SELECT * FROM accounts WHERE login = '$login' AND password = '$password'";
            $result = $connect->query($sql_find);
            if ($result->num_rows == 1) {
                $sql_update =  "UPDATE accounts SET `$type_of_data` = '$data_for_change' WHERE id = '$id'";

                if ($connect->query($sql_update) == true) {

                    if ($type_of_data == "login") {
                        $_SESSION["login"] = $data_for_change;
                    }

                    echo json_encode([
                        'result'=>true,
                        'message'=>'Обновление прошло успешно',
                        'new_data' => $data_for_change,
                        'type_data'=>$type_of_data
                    ]);
                };
            }
        } else {
            $sql_find = "SELECT * FROM accounts WHERE login = '$login' AND password = '$password'";
            $result = $connect->query($sql_find);
            if ($result->num_rows == 1) {

                $data_for_change = md5($data_for_change);
                $sql_update =  "UPDATE accounts SET `$type_of_data` = '$data_for_change' WHERE id = '$id'";

                if ($connect->query($sql_update) == true) {
                    $_SESSION['password'] = $data_for_change;
                    echo json_encode([
                        'result'=>true,
                        'message'=>'Обновление прошло успешно',
                        'new_data' => $data_for_change,
                        'type_data'=>$type_of_data
                    ]);
                };
            }
        }

    }
}

if (isset($_POST["file_data"])) {
    $file_data = json_decode($_POST['file_data']);
    $base64 = $file_data->base64;
    $filename = $file_data->filename;
    $file_data = $filename ."_". $base64;

    $login = $_SESSION["login"];
    $password = $_SESSION['password'];
    $id = $_SESSION['id'];

    $newName = str_replace(" ", "_",$filename);
    $realFile = base64_decode(explode(',',$base64)[1]);
    $path = "assets/img/".uniqid()."_".$newName;
    file_put_contents($path,$realFile);

    require('config.php');
    if ($con_result['result'] == true) {
        $sql_check = "SELECT * FROM accounts WHERE login = '$login' AND password = '$password'";
        $result = $connect->query($sql_check);
        if ($result->num_rows == 1) {
            $sql_update =  "UPDATE accounts SET foto = '$file_data' WHERE id = '$id'";
            if ($connect->query($sql_update) == true) {
                echo json_encode([
                    'result'=>true,
                    'message'=>'Фото загружено',
                    'filesrc' => $path,
                    'filename'=>$filename
                ]);
            }
        }
    }



}
?>
