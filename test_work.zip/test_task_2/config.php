<?php

$host = "localhost";
$db_name = "task_base";
$db_user = "root";
$db_password = "";

$connect = new mysqli($host, $db_user, $db_password, $db_name);
mysqli_set_charset($connect, 'utf8');
if ($connect) {
    return $con_result = [
        'result' =>true
    ];
} else {
    return $con_result = [
        'result' =>false,
        'error' => mysqli_connect_error()
    ];
}
