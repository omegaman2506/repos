let auth_try_counter = 0;

    // отправка формы с главной страницы
    document.querySelector('.form_auth').onsubmit=function(event) {
        event.preventDefault();

        // проверка на заполненность
        if ((document.querySelector('#form_login').value == "") && (document.querySelector('#form_password').value == "")) {
            document.querySelector('.card_error_block').innerHTML="Вы не ввели логин и пароль!";
            document.querySelector('.card_error_block').classList.toggle('show');
            setTimeout((function() {
                document.querySelector('.card_error_block').classList.toggle('show');
                document.querySelector('.card_error_block').innerHTML="";
            }),2500);
            return '';
        } else if (document.querySelector('#form_login').value == "") {
            document.querySelector('.card_error_block').innerHTML="Вы не ввели логин!";
            document.querySelector('.card_error_block').classList.toggle('show');
            setTimeout((function() {
                document.querySelector('.card_error_block').classList.toggle('show');
                document.querySelector('.card_error_block').innerHTML="";
            }),2500);
            return '';
        } else if (document.querySelector('#form_password').value == "") {
            document.querySelector('.card_error_block').innerHTML="Вы не ввели пароль!";
            document.querySelector('.card_error_block').classList.toggle('show');
            setTimeout((function() {
                document.querySelector('.card_error_block').classList.toggle('show');
                document.querySelector('.card_error_block').innerHTML="";
            }),2500);
            return '';
        }

        // отправка на авторизацию / регистрацию
        if (event.submitter.id == "form_send_btn") {

            let count_fall_data= document.cookie.match(/bad_pass=(.+?)(;|$)/);
            count_fall_data = count_fall_data !==null ? count_fall_data[1] : 0;

            console.log(count_fall_data);
            // отправка данных
            let data_body = {
                "login": document.querySelector('#form_login').value,
                "password": document.querySelector('#form_password').value,
                "auth": true,
                "count_bad_pass": count_fall_data
            };

            let data = new FormData();
            data.append("auth_data", JSON.stringify(data_body));

            fetch("server.php", {
                method: "POST",
                body: data,
            }).then((response) => {
                if (response.status !== 200) {
                    return Promise.reject();
                }
                return response.json();
            })
                .then(function(datta){
                    console.log(datta);
                    if (datta.result == true) {
                        document.querySelector('.welcome_block').innerHTML = datta.message;
                        document.querySelector('.ibh_name span').innerHTML = datta.name ? datta.name : "Не указано";
                        document.querySelector('.ibh_password span').innerHTML = datta.password ? datta.password : "Не указано";
                        document.querySelector('.ibh_birthdate span').innerHTML = datta.birthdate ? datta.birthdate : "Не указано";
                        document.querySelector('.ibh_login span').innerHTML = datta.login ? datta.login : "Не указано";

                        document.querySelector('.step_1').classList.toggle('hide');
                        document.querySelector('.step_2').classList.toggle('show');
                        setTimeout((function() {
                            document.querySelector('.welcome_block').style.display="none";
                        }),10000);
                    } else {
                        document.querySelector('.card_error_block').innerHTML=datta.message;
                        document.querySelector('.card_error_block').classList.toggle('show');
                        setTimeout((function() {
                            document.querySelector('.card_error_block').classList.toggle('show');
                            document.querySelector('.card_error_block').innerHTML="";
                        }),2500);
                    }
                })
                .catch((reason) => console.log(reason));
        } else if (event.submitter.id == "form_reg_btn") {

                // отправка данных
                let data_body = {
                    "login": document.querySelector('#form_login').value,
                    "password": document.querySelector('#form_password').value,
                    "reg": true
                };

                let data = new FormData();
                data.append("reg_data", JSON.stringify(data_body));

                fetch("server.php", {
                    method: "POST",
                    body: data,
                }).then((response) => {
                    if (response.status !== 200) {
                        return Promise.reject();
                    }
                    return response.json();
                })
                    .then(function(datta){
                        console.log(datta);
                        if (datta.result == true) {
                            document.querySelector('.welcome_block').innerHTML = datta.message;
                            document.querySelector('.ibh_name span').innerHTML = "Не указано";
                            document.querySelector('.ibh_password span').innerHTML = datta.info.password ? datta.info.password : "Не указано";
                            document.querySelector('.ibh_birthdate span').innerHTML = "Не указано";
                            document.querySelector('.ibh_login span').innerHTML = datta.info.login ? datta.info.login : "Не указано";

                            document.querySelector('.step_1').classList.toggle('hide');
                            document.querySelector('.step_2').classList.toggle('show');
                            setTimeout((function() {
                                document.querySelector('.welcome_block').style.display="none";
                            }),10000);
                        } else {
                            document.querySelector('.card_error_block').innerHTML=datta.message;
                            document.querySelector('.card_error_block').classList.toggle('show');
                            setTimeout((function() {
                                document.querySelector('.card_error_block').classList.toggle('show');
                                document.querySelector('.card_error_block').innerHTML="";
                            }),2500);
                        }
                    })
                    .catch((reason) => console.log(reason));
            }
    }

    // форма изменения данных
    // кнопка закрыть
    document.querySelector('.close_change_form').onclick=function(event) {
        event.preventDefault();
        console.log(event);
        document.querySelector('.change_user_data_block').style.display="none";
        document.querySelectorAll('p[class*="ibh_"]').forEach((item,index) => {
            item.classList.remove('active_change');
        });
        document.querySelectorAll('.user_info_change').forEach((item,index) => {
            item.style.display="inline-block";
        });
    }

    // кнопка изменить рядом с текстом
    document.querySelectorAll('.user_info_change').forEach((item,index) => {
        item.onclick=function(event) {
            event.preventDefault();
            console.log(event);

            document.querySelector('#type_of_info').value = this.getAttribute('id');
            console.log(document.querySelector('#type_of_info').value);
            document.querySelectorAll('.user_info_change').forEach((item,index) => {
                item.style.display="none";
            });
            document.querySelector('.change_user_data_block').style.display="block";
            this.previousElementSibling.classList.toggle('active_change');
        }
    });


    // отправка новых данных
    document.querySelector('#form_user_data_change').onsubmit=function(event) {
        event.preventDefault();
        console.log(event);
        console.log(document.querySelector('#input_user_data_change').value);
        console.log(document.querySelector('#accept_user_data_change').value);
        console.log(document.querySelector('#type_of_info').value);

        // проверка на заполненность
        if ((document.querySelector('#input_user_data_change').value == "") && (document.querySelector('#accept_user_data_change').value == "")) {
            document.querySelector('.card_error_block.type2').innerHTML="Вы ничего не ввели!";
            document.querySelector('.card_error_block.type2').classList.toggle('show');
            setTimeout((function() {
                document.querySelector('.card_error_block.type2').classList.toggle('show');
                document.querySelector('.card_error_block.type2').innerHTML="";
            }),2500);
            return '';
        } else if (document.querySelector('#input_user_data_change').value == "") {
            document.querySelector('.card_error_block.type2').innerHTML="Вы не ввели новое значение!";
            document.querySelector('.card_error_block.type2').classList.toggle('show');
            setTimeout((function() {
                document.querySelector('.card_error_block.type2').classList.toggle('show');
                document.querySelector('.card_error_block.type2').innerHTML="";
            }),2500);
            return '';
        } else if (document.querySelector('#accept_user_data_change').value == "") {
            document.querySelector('.card_error_block.type2').innerHTML="Вы не подтвердили новое значение!";
            document.querySelector('.card_error_block.type2').classList.toggle('show');
            setTimeout((function() {
                document.querySelector('.card_error_block.type2').classList.toggle('show');
                document.querySelector('.card_error_block.type2').innerHTML="";
            }),2500);
            return '';
        }

        if (document.querySelector('#input_user_data_change').value != document.querySelector('#accept_user_data_change').value) {
            document.querySelector('.card_error_block.type2').innerHTML="Введенные данные не совпадают!";
            document.querySelector('.card_error_block.type2').classList.toggle('show');
            setTimeout((function() {
                document.querySelector('.card_error_block.type2').classList.toggle('show');
                document.querySelector('.card_error_block.type2').innerHTML="";
            }),2500);
            return '';
        }

        console.log('все проверки');
        let data_body = {
            "data_from_input": document.querySelector('#accept_user_data_change').value,
            "type_data": document.querySelector('#type_of_info').value
        };

        let data = new FormData();
        data.append("change_data", JSON.stringify(data_body));

        console.log('перед аякс');

        fetch("server.php", {
            method: "POST",
            body: data,
        }).then((response) => {
            if (response.status !== 200) {
                return Promise.reject();
            }
            return response.json();
        })
        .then(function(datta) {
            console.log(datta);
            if (datta.result == true) {
                document.querySelector('.card_error_block.type2').innerHTML=datta.message;
                document.querySelector('.card_error_block.type2').style.color="green";
                document.querySelector('.card_error_block.type2').classList.toggle('show');

                //document.querySelector('.p[class="ibh_"'+datta.type_data+']');
                document.querySelector('.active_change > span').innerHTML=datta.new_data;



                setTimeout((function() {
                    document.querySelector('.card_error_block.type2').classList.toggle('show');
                    document.querySelector('.card_error_block.type2').style.color="red";
                    document.querySelector('.card_error_block.type2').innerHTML="";

                    document.querySelector('#input_user_data_change').value = "";
                    document.querySelector('#accept_user_data_change').value = "";
                    document.querySelector('.change_user_data_block').style.display = "none";
                    document.querySelectorAll('.user_info_change').forEach((item,index) => {
                        item.style.display="inline-block";
                    });
                    document.querySelectorAll('p[class*="ibh_"]').forEach((item,index) => {
                        item.classList.remove('active_change');
                    });
                }),2500);
            } else {
                document.querySelector('.card_error_block.type2').innerHTML="Обновление не удалось";
                document.querySelector('.card_error_block.type2').classList.toggle('show');
                setTimeout((function() {
                    document.querySelector('.card_error_block.type2').classList.toggle('show');
                    document.querySelector('.card_error_block.type2').innerHTML="";
                }),2500);
            }

        })
        .catch((reason) => console.log(reason));
    }

    // выход на главную
    document.querySelector('.logout_block').onclick=function(event) {
        event.preventDefault();
        location.href="index.html";
    }

    // загрузка файла
    document.querySelector('#user_foto_info').onchange=function(event) {
        event.preventDefault();

        let files = this.files[0];
        let reader = new FileReader();

        reader.onload = function(ev) {
            let file_base64 = ev.target.result;
            let file_name = files.name;

            let data_body = {
                "base64": file_base64,
                "filename": file_name
            };

            let data = new FormData();
            data.append("file_data", JSON.stringify(data_body));

            fetch("server.php", {
                method: "POST",
                body: data,
            }).then((response) => {
                if (response.status !== 200) {
                    return Promise.reject();
                }
                return response.json();
            }).then(function(datta){
                console.log(datta);
                if (datta.result == true) {
                    document.querySelector('.img_update_form img').setAttribute('src',datta.filesrc);
                    document.querySelector('#user_foto_info').value = '';
                } else {

                }



            }).catch((reason) => console.log(reason));
        }
        reader.readAsDataURL(files);
    }
